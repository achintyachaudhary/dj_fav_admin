from django.contrib import admin

from favorite.models import Favorite

admin.site.register(Favorite)
